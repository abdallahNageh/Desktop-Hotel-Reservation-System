package com.example.hotel_project;

import javafx.scene.input.MouseEvent;
import BackEnd.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GuestController {

    @FXML private Label  hi_userName;
    @FXML private Button ViewAvilableRooms;
    @FXML private Button ViewMyReservation;
    @FXML private Button btn_logout;

    @FXML
    public void initialize() {
        Guest currentGuest = HotelDatabase.getCurrentGuest();
        if (currentGuest != null) {
            hi_userName.setText("Hi, " + currentGuest.getUsername() + " 👋  |  Balance: "
                    + String.format("%.0f", currentGuest.getBalance()) + " EGP");
        }

        ViewAvilableRooms.setOnAction(e -> loadScene("/com/example/hotel_project/ViewAvailableRoom.fxml"));
        ViewMyReservation.setOnAction(e -> loadScene("/com/example/hotel_project/MyReservations.fxml"));
        if (btn_logout != null) {
            btn_logout.setOnAction(e -> {
                HotelDatabase.setCurrentGuest(null);
                loadScene("/com/example/hotel_project/login.fxml");
            });
        }
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Stage stage = (Stage) hi_userName.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onHoverRooms(MouseEvent mouseEvent) {
    }

    public void onLeaveRooms(MouseEvent mouseEvent) {
    }
}
