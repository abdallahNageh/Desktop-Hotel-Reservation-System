
package model;

public enum RoomTypeName {
    SINGLE,
    DOUBLE,
    SUITE
}