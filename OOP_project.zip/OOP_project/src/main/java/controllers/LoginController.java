package controllers  ;

import model.* ;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginController {

    @FXML
    private TextField Usernme;

    @FXML
    private PasswordField Password;

    @FXML
    private void handleLogin() {
        String user = Usernme.getText();
        String pass = Password.getText();

        Guest guest = new Guest("", "");

        if (guest.login(user, pass)) {
            openMain();
        } else {
            System.out.println("Login Failed");
        }
    }

    @FXML
    private void handleGuest() {
        HotelDatabase.setCurrentGuest(null);
        openMain();
    }

    private void openMain() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}