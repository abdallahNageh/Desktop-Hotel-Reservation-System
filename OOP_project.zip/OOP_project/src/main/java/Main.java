import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application  {
    @Override
    public void start(Stage stage) throws Exception{
        Parent page1Root = FXMLLoader.load(
                getClass().getResource("/com/example/oop_project/hello-view.fxml"));        Scene scene = new Scene(page1Root);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args){
        launch(args);
    }
}