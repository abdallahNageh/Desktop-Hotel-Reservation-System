package BackEnd;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 *  Hotel System — Comprehensive Sample Data
 *  Drop this into the BackEnd package and call
 *  SampleData.load() instead of (or after) HotelDatabase.initializeData()
 * ============================================================
 */
public class SampleData {

    public static void load() {

        // ── 1. AMENITIES ─────────────────────────────────────────────────────
        Amenity wifi        = new Amenity("WiFi",         "High-speed fiber internet");
        Amenity tv          = new Amenity("Smart TV",     "55\" 4K Smart TV with Netflix");
        Amenity minibar     = new Amenity("Mini Bar",     "Stocked mini-bar & snacks");
        Amenity jacuzzi     = new Amenity("Jacuzzi",      "Private in-room jacuzzi");
        Amenity ac          = new Amenity("A/C",          "Central air conditioning");
        Amenity parking     = new Amenity("Parking",      "Underground secure parking");
        Amenity breakfast   = new Amenity("Breakfast",    "Daily complimentary breakfast");
        Amenity gym         = new Amenity("Gym Access",   "24-hour fitness center access");

        HotelDatabase.addAmenity(wifi);
        HotelDatabase.addAmenity(tv);
        HotelDatabase.addAmenity(minibar);
        HotelDatabase.addAmenity(jacuzzi);
        HotelDatabase.addAmenity(ac);
        HotelDatabase.addAmenity(parking);
        HotelDatabase.addAmenity(breakfast);
        HotelDatabase.addAmenity(gym);

        // ── 2. ROOM TYPES ─────────────────────────────────────────────────────
        RoomType single = new RoomType(RoomTypeName.SINGLE, "Cozy single room for solo travelers", 500.0);
        RoomType dbl    = new RoomType(RoomTypeName.DOUBLE, "Spacious double room for couples",    900.0);
        RoomType suite  = new RoomType(RoomTypeName.SUITE,  "Luxury suite with panoramic view",   2500.0);

        HotelDatabase.addRoomType(single);
        HotelDatabase.addRoomType(dbl);
        HotelDatabase.addRoomType(suite);

        // ── 3. ROOMS ──────────────────────────────────────────────────────────
        // Single rooms  (101-105)
        List<Amenity> singleAmenities = Arrays.asList(wifi, tv, ac);
        Room r101 = new Room(101, new ArrayList<>(singleAmenities), true,  single);
        Room r102 = new Room(102, new ArrayList<>(singleAmenities), true,  single);
        Room r103 = new Room(103, new ArrayList<>(singleAmenities), false, single); // occupied
        Room r104 = new Room(104, new ArrayList<>(singleAmenities), true,  single);
        Room r105 = new Room(105, new ArrayList<>(singleAmenities), true,  single);

        r101.setPricePerNight(500); r102.setPricePerNight(500);
        r103.setPricePerNight(500); r104.setPricePerNight(500);
        r105.setPricePerNight(500);

        // Double rooms  (201-204)
        List<Amenity> doubleAmenities = Arrays.asList(wifi, tv, ac, minibar, parking);
        Room r201 = new Room(201, new ArrayList<>(doubleAmenities), true,  dbl);
        Room r202 = new Room(202, new ArrayList<>(doubleAmenities), false, dbl); // occupied
        Room r203 = new Room(203, new ArrayList<>(doubleAmenities), true,  dbl);
        Room r204 = new Room(204, new ArrayList<>(doubleAmenities), true,  dbl);

        r201.setPricePerNight(900); r202.setPricePerNight(900);
        r203.setPricePerNight(900); r204.setPricePerNight(900);

        // Suite rooms  (301-302)
        List<Amenity> suiteAmenities = Arrays.asList(wifi, tv, ac, minibar, jacuzzi, breakfast, gym, parking);
        Room r301 = new Room(301, new ArrayList<>(suiteAmenities), true,  suite);
        Room r302 = new Room(302, new ArrayList<>(suiteAmenities), false, suite); // occupied

        r301.setPricePerNight(2500); r302.setPricePerNight(2500);

        for (Room r : Arrays.asList(r101,r102,r103,r104,r105,r201,r202,r203,r204,r301,r302))
            HotelDatabase.addRoom(r);

        // ── 4. ADMINS ─────────────────────────────────────────────────────────
        Admin adminMain  = new Admin("admin",   "Admin@123",  LocalDate.of(1985, 3, 15), 10);
        Admin adminSara  = new Admin("sara.adm","Sara@2024",  LocalDate.of(1990, 7, 22),  5);

        HotelDatabase.addAdmin(adminMain);
        HotelDatabase.addAdmin(adminSara);

        // ── 5. RECEPTIONISTS ──────────────────────────────────────────────────
        Receptionist rec1 = new Receptionist("karim.r",  "Karim@456", LocalDate.of(1995, 1, 10), 3, "Morning Shift");
        Receptionist rec2 = new Receptionist("nour.r",   "Nour@789",  LocalDate.of(1998, 6, 5),  2, "Evening Shift");
        Receptionist rec3 = new Receptionist("omar.r",   "Omar@321",  LocalDate.of(1993, 11, 20), 4, "Night Shift");

        HotelDatabase.addReceptionist(rec1);
        HotelDatabase.addReceptionist(rec2);
        HotelDatabase.addReceptionist(rec3);

        // ── 6. GUESTS ─────────────────────────────────────────────────────────
        Guest g1 = new Guest("ahmed.hassan", "Ahmed@2024",  LocalDate.of(1990, 4, 12), 15000, "15 Tahrir St, Cairo",      Gender.MALE,   "Quiet floor, high room");
        Guest g2 = new Guest("laila.m",      "Laila@567",   LocalDate.of(1995, 8, 25), 30000, "7 Corniche Ave, Alex",     Gender.FEMALE, "Non-smoking, city view");
        Guest g3 = new Guest("peter.g",      "Peter@999",   LocalDate.of(1988, 12, 1), 50000, "22 Nile Rd, Giza",         Gender.MALE,   "Suite preferred, jacuzzi");
        Guest g4 = new Guest("hana.t",       "Hana@2025",   LocalDate.of(2000, 3, 30), 8000,  "5 Palm St, Sharm",         Gender.FEMALE, "Ground floor preferred");
        Guest g5 = new Guest("mark.w",       "Mark@1234",   LocalDate.of(1982, 7, 7),  75000, "10 Ring Rd, New Cairo",    Gender.MALE,   "King bed, business desk");
        Guest g6 = new Guest("nadia.s",      "Nadia@Abc1",  LocalDate.of(1993, 5, 18), 20000, "3 Sphinx Sq, Cairo",       Gender.FEMALE, "Double, upper floor");
        Guest g7 = new Guest("youssef.k",    "Youssef@22",  LocalDate.of(1979, 9, 14), 5000,  "88 Delta St, Mansoura",    Gender.MALE,   "Single, cheap, wifi");

        for (Guest g : Arrays.asList(g1,g2,g3,g4,g5,g6,g7))
            HotelDatabase.addGuest(g);

        // ── 7. RESERVATIONS ───────────────────────────────────────────────────
        // PENDING
        Reservation res1 = new Reservation(g4, r104, LocalDate.of(2026,5,10), LocalDate.of(2026,5,14));
        r104.setAvailable(false);
        HotelDatabase.addReservation(res1);

        // CONFIRMED
        Reservation res2 = new Reservation(g2, r201, LocalDate.of(2026,5,1), LocalDate.of(2026,5,5));
        res2.confirm();
        r201.setAvailable(false);
        HotelDatabase.addReservation(res2);

        // CONFIRMED
        Reservation res3 = new Reservation(g5, r301, LocalDate.of(2026,5,3), LocalDate.of(2026,5,10));
        res3.confirm();
        r301.setAvailable(false);
        HotelDatabase.addReservation(res3);

        // CHECKED_IN (manually set status)
        Reservation res4 = new Reservation(g1, r103, LocalDate.of(2026,4,28), LocalDate.of(2026,5,3));
        res4.confirm();
        res4.setStatus(ReservationStatus.CHECKED_IN);
        // r103 already marked unavailable above
        HotelDatabase.addReservation(res4);

        // CHECKED_IN
        Reservation res5 = new Reservation(g3, r302, LocalDate.of(2026,4,25), LocalDate.of(2026,5,2));
        res5.confirm();
        res5.setStatus(ReservationStatus.CHECKED_IN);
        // r302 already marked unavailable
        HotelDatabase.addReservation(res5);

        // CANCELLED
        Reservation res6 = new Reservation(g6, r102, LocalDate.of(2026,4,20), LocalDate.of(2026,4,24));
        res6.cancel();
        // room stays available since it was cancelled
        HotelDatabase.addReservation(res6);

        // COMPLETED — add an invoice too
        Reservation res7 = new Reservation(g7, r105, LocalDate.of(2026,4,10), LocalDate.of(2026,4,13));
        res7.confirm();
        res7.setStatus(ReservationStatus.COMPLETED);
        HotelDatabase.addReservation(res7);

        // Invoice for completed reservation  (3 nights × 500 = 1500)
        Invoice inv1 = new Invoice(1500.0, PaymentMethod.CASH, LocalDate.of(2026,4,13));
        HotelDatabase.addInvoice(inv1);

        // Another PENDING reservation — different guest, same room different dates
        Reservation res8 = new Reservation(g6, r203, LocalDate.of(2026,5,15), LocalDate.of(2026,5,20));
        HotelDatabase.addReservation(res8);

        // CONFIRMED future booking
        Reservation res9 = new Reservation(g1, r204, LocalDate.of(2026,6,1), LocalDate.of(2026,6,7));
        res9.confirm();
        HotelDatabase.addReservation(res9);

        System.out.println("=== Sample Data Loaded Successfully ===");
        System.out.println("Amenities   : " + HotelDatabase.getAmenities().size());
        System.out.println("Room Types  : " + HotelDatabase.getRoomTypes().size());
        System.out.println("Rooms       : " + HotelDatabase.getRooms().size());
        System.out.println("Admins      : " + HotelDatabase.getAdmins().size());
        System.out.println("Receptionists: " + HotelDatabase.getReceptionists().size());
        System.out.println("Guests      : " + HotelDatabase.getGuests().size());
        System.out.println("Reservations: " + HotelDatabase.getReservations().size());
    }
}