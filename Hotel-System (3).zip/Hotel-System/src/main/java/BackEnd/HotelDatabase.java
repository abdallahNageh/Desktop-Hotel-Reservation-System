package BackEnd;

import java.time.LocalDate;
import java.util.*;


public class HotelDatabase {

    // 🔹 Data Storage
    private static ArrayList<Receptionist> receptionists = new ArrayList<>();
    private static ArrayList<Admin> admins = new ArrayList<>();
    private static ArrayList<Guest> guests = new ArrayList<>();
    private static ArrayList<Room> rooms = new ArrayList<>();
    private static ArrayList<Reservation> reservations = new ArrayList<>();
    private static ArrayList<Invoice> invoices = new ArrayList<>();
    private static ArrayList<RoomType> roomTypes = new ArrayList<>();
    private static ArrayList<Amenity> amenities = new ArrayList<>();
    private static Admin currentAdmin = null ;
    private static Guest currentGuest = null ;
    private static Receptionist currentReceptionist = null ;

    public static Guest getCurrentGuest() {
        return currentGuest;
    }

    public static void setCurrentGuest(Guest currentGuest) {
        HotelDatabase.currentGuest = currentGuest;
    }

    public static Admin getCurrentAmdin() {
        return currentAdmin;
    }

    public  static void setCurrentAmdin(Admin currentAmdin) {
        HotelDatabase.currentAdmin = currentAmdin;
    }

    public static Receptionist getCurrentReceptionist() {
        return currentReceptionist;
    }

    public static void setCurrentReceptionist(Receptionist currentReceptionist) {
        HotelDatabase.currentReceptionist = currentReceptionist;
    }

    // 🔹 ADD
    public static void addGuest(Guest guest) {
        if (findGuest(guest.getUsername()) != null) {
            System.out.println("Guest with this username already exists.");
            return;
            }
        guests.add(guest);
    }

    public static void addRoom(Room room) {
        if (findRoom(room.getRoomNumber()) != null) {
            System.out.println("Room with this number already exists.");
            return;
            }
        rooms.add(room);
    }

    public static void addReservation(Reservation reservation) {
        if (reservation == null) {
            System.out.println("Invalid reservation.");
            return;
            }

        for (Reservation r : reservations) {

            if (r.getRoom().equals(reservation.getRoom()) &&
                r.getStatus() != ReservationStatus.CANCELLED) {

                if (!(reservation.getCheckOutDate().isBefore(r.getCheckInDate()) ||
                reservation.getCheckInDate().isAfter(r.getCheckOutDate()))) {

                    System.out.println("Room already booked for these dates.");
                    return;
                    }
            }
        }

        reservations.add(reservation);
    }

    public static void addInvoice(Invoice invoice) {
        invoices.add(invoice);
    }

    public static void addRoomType(RoomType type) {
        for (RoomType rt : roomTypes) {
            if (rt.getId() == type.getId()) {
                System.out.println("RoomType with this ID already exists.");
                return;
                }
        }
        roomTypes.add(type);
    }

    public static void addAmenity(Amenity amenity) {
        if (findAmenity(amenity.getId()) != null) {
            System.out.println("Amenity with this ID already exists.");
            return;
        }
        amenities.add(amenity);
    }
    public static void addAdmin(Admin admin){admins.add(admin);}
    public static void addReceptionist(Receptionist receptionist){receptionists.add(receptionist);}

    // 🔹 FIND
    public static Guest findGuest(String username) {
        for (Guest g : guests) {
            if (g.getUsername().equals(username)) {
                return g;
            }
        }
        return null;
    }

    public static Room findRoom(int roomNumber) {
        for (Room r : rooms) {
            if (r.getRoomNumber() == roomNumber) {
                return r;
            }
        }
        return null;
    }

    public static Amenity findAmenity(int id) {
        for (Amenity a : amenities) {
            if (a.getId() == id) {
                return a;
            }
        }
        return null;
    }
    public static Admin findAdmin(String name, String password){
        for (Admin a : admins){
            if(a.getUsername().equals(name) && a.getPassword().equals(password)) {
                return a;
            }
        }
        return null;
    }
    public static Receptionist findReceptionist(String name, String password){
        for (Receptionist a : receptionists){
            if(a.getUsername().equals(name) && a.getPassword().equals(password)) {
                return a;
            }
        }
        return null;
    }

    // 🔹 REMOVE
    public static void removeGuest(Guest guest) {
        guests.remove(guest);
    }

    public static void removeRoom(Room room) {
        rooms.remove(room);

    }

    public static void removeReservation(Reservation reservation) {
             reservations.remove(reservation);
    }

    public static void removeAmenity(Amenity amenity) {
            amenities.remove(amenity);
    }

    // 🔹 GETTERS (optional)

    public static ArrayList<Admin> getAdmins() {
        return admins;
    }
    public static ArrayList<Receptionist> getReceptionists() {
        return receptionists;
    }
    public static ArrayList<Guest> getGuests() {
        return guests;
    }

    public static ArrayList<Room> getRooms() {
        return rooms;
    }

    public static ArrayList<Reservation> getReservations() {
        return reservations;
    }

    public static ArrayList<Amenity> getAmenities() {
        return amenities;
    }

    public static ArrayList<RoomType> getRoomTypes() {
        return roomTypes;
    }

    // 🔹 Dummy Data
    public static void initializeData() {

        // --- Admins ---
        admins.add(new Admin("admin", "admin123", LocalDate.of(1985, 3, 15), 8));

        // --- Receptionists ---
        receptionists.add(new Receptionist("karim", "karim123", LocalDate.of(1995, 1, 10), 8, "Front Desk"));
        receptionists.add(new Receptionist("nour",  "nour123",  LocalDate.of(1998, 6, 5),  8, "Front Desk"));

        // --- Guests ---
        Guest g1 = new Guest("ahmed",  "ahmed123",  LocalDate.of(1990, 4, 12), 15000, "Cairo",    Gender.MALE,   "High floor");
        Guest g2 = new Guest("laila",  "laila123",  LocalDate.of(1995, 8, 25), 30000, "Alex",     Gender.FEMALE, "City view");
        Guest g3 = new Guest("peter",  "peter123",  LocalDate.of(1988, 12, 1), 50000, "Giza",     Gender.MALE,   "Jacuzzi");
        guests.add(g1);
        guests.add(g2);
        guests.add(g3);

        // --- Amenities ---
        Amenity wifi    = new Amenity("WiFi",      "High-speed internet");
        Amenity tv      = new Amenity("Smart TV",  "55\" 4K TV");
        Amenity ac      = new Amenity("A/C",       "Central air conditioning");
        Amenity minibar = new Amenity("Mini Bar",  "Stocked mini-bar");
        Amenity jacuzzi = new Amenity("Jacuzzi",   "Private jacuzzi");
        amenities.add(wifi);
        amenities.add(tv);
        amenities.add(ac);
        amenities.add(minibar);
        amenities.add(jacuzzi);

        // --- Room Types ---
        RoomType single = new RoomType(RoomTypeName.SINGLE, "Single room", 500);
        RoomType dbl    = new RoomType(RoomTypeName.DOUBLE, "Double room", 900);
        RoomType suite  = new RoomType(RoomTypeName.SUITE,  "Luxury suite", 2500);
        roomTypes.add(single);
        roomTypes.add(dbl);
        roomTypes.add(suite);

        // --- Rooms ---
        Room r101 = new Room(101, Arrays.asList(wifi, tv, ac),              true,  single);  r101.setPricePerNight(500);
        Room r102 = new Room(102, Arrays.asList(wifi, tv, ac),              true,  single);  r102.setPricePerNight(500);
        Room r201 = new Room(201, Arrays.asList(wifi, tv, ac, minibar),     true,  dbl);     r201.setPricePerNight(900);
        Room r202 = new Room(202, Arrays.asList(wifi, tv, ac, minibar),     false, dbl);     r202.setPricePerNight(900);
        Room r301 = new Room(301, Arrays.asList(wifi, tv, ac, minibar, jacuzzi), true, suite); r301.setPricePerNight(2500);
        rooms.add(r101);
        rooms.add(r102);
        rooms.add(r201);
        rooms.add(r202);
        rooms.add(r301);

        // --- Reservations ---
        // PENDING
        Reservation res1 = new Reservation(g1, r101, LocalDate.of(2026, 5, 10), LocalDate.of(2026, 5, 14));
        r101.setAvailable(false);
        reservations.add(res1);

        // CONFIRMED
        Reservation res2 = new Reservation(g2, r201, LocalDate.of(2026, 5, 1), LocalDate.of(2026, 5, 5));
        res2.confirm();
        r201.setAvailable(false);
        reservations.add(res2);

        // CHECKED_IN
        Reservation res3 = new Reservation(g3, r202, LocalDate.of(2026, 4, 28), LocalDate.of(2026, 5, 3));
        res3.confirm();
        res3.setStatus(ReservationStatus.CHECKED_IN);
        reservations.add(res3);

        // CANCELLED
        Reservation res4 = new Reservation(g1, r102, LocalDate.of(2026, 4, 1), LocalDate.of(2026, 4, 5));
        res4.cancel();
        reservations.add(res4);

        // COMPLETED + Invoice
        Reservation res5 = new Reservation(g2, r102, LocalDate.of(2026, 3, 10), LocalDate.of(2026, 3, 13));
        res5.confirm();
        res5.setStatus(ReservationStatus.COMPLETED);
        reservations.add(res5);
        invoices.add(new Invoice(1500.0, PaymentMethod.CASH, LocalDate.of(2026, 3, 13)));
    }

}