package BackEnd;

public enum PaymentMethod {
    CASH,
    CREDIT_CARD,
    ONLINE
}