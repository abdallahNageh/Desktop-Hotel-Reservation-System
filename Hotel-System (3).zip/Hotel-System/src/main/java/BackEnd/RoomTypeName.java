
package BackEnd;

public enum RoomTypeName {
    SINGLE,
    DOUBLE,
    SUITE
}