package BackEnd;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * ChatClient - Handles client-side connection to the chat server
 * Manages message sending and receiving in a separate thread
 */
public class ChatClient {

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String username;
    private String role;
    private boolean connected = false;
    private MessageListener messageListener;

    @FunctionalInterface
    public interface MessageListener {
        void onMessageReceived(String sender, String message);
    }

    /**
     * Constructor - Connects to the chat server
     * @param host Server host address
     * @param port Server port number
     * @throws IOException if connection fails
     */
    public ChatClient(String host, int port) throws IOException {
        try {
            this.socket = new Socket(host, port);
            this.out = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8),
                    true);
            this.in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            this.connected = true;

            // Start listening for messages in background thread
            startListening();
        } catch (IOException e) {
            connected = false;
            throw new IOException("Failed to connect to chat server at " + host + ":" + port, e);
        }
    }

    /**
     * Login to the chat server
     * @param username Username of the client
     * @param role Role of the client (GUEST or RECEPTIONIST)
     * @throws IOException if login fails
     */
    public void login(String username, String role) throws IOException {
        this.username = username;
        this.role = role;
        out.println("LOGIN:" + username + ":" + role);
    }

    /**
     * Send a direct message to a specific recipient
     * @param recipient Recipient username
     * @param message Message content
     */
    public void sendMessageTo(String recipient, String message) {
        if (connected && out != null) {
            out.println("TO:" + recipient + ":" + message);
        }
    }

    /**
     * Send a broadcast message to all users
     * @param message Message content
     */
    public void sendBroadcast(String message) {
        if (connected && out != null) {
            out.println("BROADCAST:" + message);
        }
    }

    /**
     * Set the message listener callback
     * @param listener Callback to handle incoming messages
     */
    public void setMessageListener(MessageListener listener) {
        this.messageListener = listener;
    }

    /**
     * Check if client is connected
     * @return true if connected, false otherwise
     */
    public boolean isConnected() {
        return connected;
    }

    /**
     * Start listening for incoming messages in a background thread
     */
    private void startListening() {
        Thread listenerThread = new Thread(() -> {
            try {
                String line;
                while (connected && (line = in.readLine()) != null) {
                    if (messageListener != null) {
                        // Parse incoming message format: "sender:message"
                        String[] parts = line.split(":", 2);
                        if (parts.length == 2) {
                            messageListener.onMessageReceived(parts[0], parts[1]);
                        }
                    }
                }
            } catch (IOException e) {
                if (connected) {
                    System.err.println("Error listening for messages: " + e.getMessage());
                }
            } finally {
                connected = false;
            }
        });
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    /**
     * Disconnect from the server
     */
    public void disconnect() {
        try {
            connected = false;
            if (out != null) out.close();
            if (in != null) in.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            System.err.println("Error disconnecting: " + e.getMessage());
        }
    }

    /**
     * Get the current username
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Get the current role
     * @return role
     */
    public String getRole() {
        return role;
    }
}
