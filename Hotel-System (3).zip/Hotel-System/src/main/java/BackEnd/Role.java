package BackEnd;


public enum Role {
    ADMIN,
    RECEPTIONIST
}