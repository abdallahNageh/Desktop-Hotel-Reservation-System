package BackEnd;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * ChatServer - Multi-threaded chat server for hotel reservation system
 * Handles multiple concurrent client connections and message routing
 */
public class ChatServer {

    private static final int PORT = 5555;
    private ServerSocket serverSocket;
    private Set<ClientHandler> clients;
    private volatile boolean running = false;

    /**
     * Constructor - Initializes the chat server
     */



    public ChatServer() {
        this.clients = Collections.synchronizedSet(new HashSet<>());
    }

    /**
     * Start the chat server
     */
    public void start() {
        try {
            serverSocket = new ServerSocket(PORT);
            running = true;
            System.out.println("🟢 Chat Server started on port " + PORT);

            // Accept client connections in main thread
            while (running) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("📌 New client connected from " + clientSocket.getInetAddress());

                    // Handle each client in a separate thread
                    ClientHandler handler = new ClientHandler(clientSocket, this);
                    clients.add(handler);
                    new Thread(handler).start();
                } catch (SocketException e) {
                    if (running) {
                        System.err.println("Error accepting client: " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error starting server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Stop the chat server
     */
    public void stop() {
        running = false;
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException e) {
            System.err.println("Error stopping server: " + e.getMessage());
        }
        System.out.println("🔴 Chat Server stopped");
    }

    /**
     * Broadcast a message to all connected clients
     * @param sender Username of sender
     * @param message Message content
     */
    synchronized void broadcastMessage(String sender, String message) {
        String formattedMessage = sender + ":" + message;
        for (ClientHandler client : clients) {
            client.sendMessage(formattedMessage);
        }
    }
    public synchronized String getOnlineUsers() {
        StringBuilder sb = new StringBuilder();

        for (ClientHandler c : clients) {
            if (c.getUsername() != null) {
                sb.append(c.getUsername()).append(",");
            }
        }

        return sb.toString();
    }
    /**
     * Send a direct message to a specific recipient
     * @param sender Username of sender
     * @param recipient Username of recipient
     * @param message Message content
     */
    synchronized void sendMessageTo(String sender, String recipient, String message) {
        String formattedMessage = sender + ":" + message;
        for (ClientHandler client : clients) {
            if (client.getUsername().equalsIgnoreCase(recipient)) {
                client.sendMessage(formattedMessage);
                return;
            }
        }
        System.out.println("⚠️  Recipient '" + recipient + "' not found");
    }

    /**
     * Remove a client from the active clients list
     * @param handler Client handler to remove
     */
    synchronized void removeClient(ClientHandler handler) {
        clients.remove(handler);
        System.out.println("🔴 Client disconnected: " + handler.getUsername());
    }

    /**
     * Get count of connected clients
     * @return number of connected clients
     */
    public int getConnectedClientsCount() {
        return clients.size();
    }

    /**
     * Inner class - Handles individual client connections
     */
    private static class ClientHandler implements Runnable {

        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private ChatServer server;
        private String username;
        private String role;

        /**
         * Constructor
         * @param socket Client socket
         * @param server Parent server instance
         */
        ClientHandler(Socket socket, ChatServer server) {
            this.socket = socket;
            this.server = server;
            try {
                this.out = new PrintWriter(
                        new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8),
                        true);
                this.in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            } catch (IOException e) {
                System.err.println("Error initializing client handler: " + e.getMessage());
            }
        }

        /**
         * Handle client messages in a loop
         */
        @Override
        public void run() {
            try {
                String line;
                while ((line = in.readLine()) != null && server.running) {
                    handleMessage(line);
                }
            } catch (IOException e) {
                System.err.println("Error reading from client: " + e.getMessage());
            } finally {
                disconnect();
            }
        }

        /**
         * Handle incoming message from client
         * @param message Message to handle
         */
        private void handleMessage(String message) {
            if (message.startsWith("LOGIN:")) {
                handleLogin(message);
            } else if (message.startsWith("TO:")) {
                handleDirectMessage(message);
            } else if (message.startsWith("BROADCAST:")) {
                handleBroadcast(message);
            }
        }

        /**
         * Handle login message
         * Format: LOGIN:username:role
         */
        private void handleLogin(String message) {
            String[] parts = message.split(":", 3);
            if (parts.length >= 3) {
                this.username = parts[1];
                this.role = parts[2];
                System.out.println("✅ User logged in: " + username + " (" + role + ")");
            }
        }

        /**
         * Handle direct message
         * Format: TO:recipient:message
         */
        private void handleDirectMessage(String message) {
            String[] parts = message.split(":", 3);
            if (parts.length >= 3) {
                String recipient = parts[1];
                String msg = parts[2];
                server.sendMessageTo(username, recipient, msg);
            }
        }

        /**
         * Handle broadcast message
         * Format: BROADCAST:message
         */
        private void handleBroadcast(String message) {
            String[] parts = message.split(":", 2);
            if (parts.length >= 2) {
                String msg = parts[1];
                server.broadcastMessage(username, msg);
            }
        }

        /**
         * Send a message to this client
         * @param message Message to send
         */
        void sendMessage(String message) {
            if (out != null) {
                out.println(message);
            }
        }

        /**
         * Get client's username
         * @return username
         */
        String getUsername() {
            return username != null ? username : "Unknown";
        }

        /**
         * Disconnect the client
         */
        private void disconnect() {
            try {
                if (out != null) out.close();
                if (in != null) in.close();
                if (socket != null && !socket.isClosed()) socket.close();
            } catch (IOException e) {
                System.err.println("Error closing client connection: " + e.getMessage());
            }
            server.removeClient(this);
        }
    }

    /**
     * Main method - Start the chat server
     */
    public static void main(String[] args) {
        ChatServer server = new ChatServer();
        server.start();

        // Add shutdown hook for graceful shutdown
        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
    }
}
