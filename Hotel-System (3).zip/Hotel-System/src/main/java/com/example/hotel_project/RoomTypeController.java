package com.example.hotel_project;


import BackEnd.HotelDatabase;
import BackEnd.Room;
import BackEnd.RoomType;
import BackEnd.RoomTypeName;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class RoomTypeController {

    @FXML private TableView<RoomType> roomTypeTable;
    @FXML private TableColumn<RoomType, Integer> idCol;
    @FXML private TableColumn<RoomType, String> nameCol;
    @FXML private TableColumn<RoomType, String> descriptionCol;
    @FXML private TableColumn<RoomType, Double> priceCol;

    @FXML private ComboBox<RoomTypeName> nameCombo;
    @FXML private TextField descriptionField;
    @FXML private TextField priceField;
    @FXML private Label errorLabel;

    private ObservableList<RoomType> roomTypeList;

    @FXML
    public void initialize() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("basePrice"));

        nameCombo.getItems().addAll(RoomTypeName.values());

        roomTypeList = FXCollections.observableArrayList(HotelDatabase.getRoomTypes());
        roomTypeTable.setItems(roomTypeList);
    }

    @FXML
    private void handleAdd() {
        String desc = descriptionField.getText().trim();
        String priceText = priceField.getText().trim();
        errorLabel.setVisible(false);

        // التحقق من الحقول
        if (nameCombo.getValue() == null) {
            showError("Please select a room type name!");
            return;
        }
        if (desc.isEmpty()) {
            showError("Description cannot be empty!");
            return;
        }
        if (priceText.isEmpty()) {
            showError("Please enter the price!");
            return;
        }

        try {
            double price = Double.parseDouble(priceText);
            if (price <= 0) throw new NumberFormatException();

            // إنشاء وإضافة العنصر الجديد
            RoomType newRoomType = new RoomType(nameCombo.getValue(), desc, price);
            HotelDatabase.addRoomType(newRoomType);
            roomTypeList.add(newRoomType);
            clearFields();

        } catch (NumberFormatException e) {
            showError("Price must be a valid positive number!");
        }
    }

    @FXML
    private void handleEdit() {
        RoomType selected = roomTypeTable.getSelectionModel().getSelectedItem();
        errorLabel.setVisible(false);

        if (selected == null) {
            showError("Select a room type from the table to edit!");
            return;
        }

        String newDesc = descriptionField.getText().trim();
        String newPriceText = priceField.getText().trim();

        // تحديث البيانات إذا كانت الحقول غير فارغة
        if (nameCombo.getValue() != null) {
            selected.setName(nameCombo.getValue());
        }

        if (!newDesc.isEmpty()) {
            selected.setDescription(newDesc);
        }

        if (!newPriceText.isEmpty()) {
            try {
                double newPrice = Double.parseDouble(newPriceText);
                if (newPrice <= 0) throw new NumberFormatException();
                selected.setBasePrice(newPrice);
            } catch (NumberFormatException e) {
                showError("New price must be a positive number!");
                return;
            }
        }

        roomTypeTable.refresh();
        clearFields();
    }

    @FXML
    private void handleDelete() {
        RoomType selected = roomTypeTable.getSelectionModel().getSelectedItem();
        errorLabel.setVisible(false);

        if (selected == null) {
            showError("Select a room type to delete!");
            return;
        }

        HotelDatabase.getRoomTypes().remove(selected);
        roomTypeList.remove(selected);

        // حذف الغرف المرتبطة بهذا النوع
        HotelDatabase.getRooms().removeIf(r -> r.getRoomType().equals(selected));
    }

    @FXML
    private void handleBack() {
        // اكتب هنا كود الرجوع للداشبورد (مثل تحميل ملف fxml جديد)
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void clearFields() {
        nameCombo.setValue(null);
        descriptionField.clear();
        priceField.clear();
        errorLabel.setVisible(false);
    }
    @FXML
    private void handleGoToRoomType(ActionEvent event) {
        try {
            // تحميل ملف الـ FXML الخاص بأنواع الغرف
            FXMLLoader loader = new FXMLLoader(getClass().getResource("adminDashboard.fxml"));
            Parent root = loader.load();

            // الحصول على النافذة (Stage) الحالية
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // ضبط المشهد الجديد (Scene) بنفس أبعاد المشروع الموحدة
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.getMessage();
        }
    }
}

