package com.example.hotel_project;

import BackEnd.HotelDatabase;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.IOException;


public class adminDashboardControl {
    @FXML
    Label welcomeLabel;
    public void initialize(){
        welcomeLabel.setVisible(true);
        String username = HotelDatabase.getCurrentAmdin().getUsername();
        welcomeLabel.setText("Welcome "+username);
    }


    @FXML
    public void toAmenitiesManagement() {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/amenityboard.fxml"));
                Parent root = loader.load();

                // get the current stage from any element on the screen
                Stage stage = (Stage) welcomeLabel.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.getMessage();
            }
        }
        public void toRoomTypeManagement() throws Exception{
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/RoomType.fxml"));
                Parent root = loader.load();

                // get the current stage from any element on the screen
                Stage stage = (Stage) welcomeLabel.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException e) {
                e.getMessage();


        }
    }
    public void toRoomManagement() throws Exception{
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/RoomManagement.fxml"));
            Parent root = loader.load();

            // get the current stage from any element on the screen
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.getMessage();


        }
    }
    @FXML
    public void logOut(){
        HotelDatabase.setCurrentAmdin(null);
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/login.fxml"));
            Parent root = loader.load();

            // get the current stage from any element on the screen
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.getMessage();


        }

    }
    @FXML
    public void exit(){
        System.exit(0);
    }


}




