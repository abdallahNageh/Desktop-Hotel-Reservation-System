package com.example.hotel_project;

import BackEnd.HotelDatabase;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainClass extends Application  {
    public void start(Stage stage) throws Exception{
        HotelDatabase.initializeData();
        Parent page1Root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(page1Root);
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args){
        launch(args);
    }

}
