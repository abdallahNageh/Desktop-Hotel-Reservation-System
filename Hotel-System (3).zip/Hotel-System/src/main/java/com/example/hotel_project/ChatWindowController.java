package com.example.hotel_project;

import BackEnd.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ChatWindowController {

    @FXML private TextArea txt_messages;
    @FXML private TextField txt_input;
    @FXML private Button btn_send;
    @FXML private Button btn_connect;
    @FXML private ComboBox<String> cmb_recipients;
    @FXML private Label lbl_status;

    private ChatClient chatClient;
    private String currentUsername;
    private String currentRole;
    private String selectedRecipient;
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    @FXML
    public void initialize() {
        // Get current user info
        Guest guest = HotelDatabase.getCurrentGuest();
        Receptionist receptionist = HotelDatabase.getCurrentReceptionist();

        if (guest != null) {
            currentUsername = guest.getUsername();
            currentRole = "GUEST";
            populateGuestRecipients();
        } else if (receptionist != null) {
            currentUsername = receptionist.getUsername();
            currentRole = "RECEPTIONIST";
            populateReceptionistRecipients();
        } else {
            showError("Error", "No user logged in!");
            return;
        }

        // Set default recipient
        if (cmb_recipients.getItems().size() > 0) {
            cmb_recipients.getSelectionModel().selectFirst();
            selectedRecipient = cmb_recipients.getValue();
        }

        // Event handlers
        btn_connect.setOnAction(e -> connectToServer());
        btn_send.setOnAction(e -> sendMessage());
        txt_input.setOnAction(e -> sendMessage()); // Enter key to send
        cmb_recipients.setOnAction(e -> selectedRecipient = cmb_recipients.getValue());
    }

    private void populateGuestRecipients() {
        ObservableList<String> recipients = FXCollections.observableArrayList();

        // 🔥 بدل "Receptionist" الثابت
        for (Receptionist r : HotelDatabase.getReceptionists()) {
            recipients.add(r.getUsername());
        }

        cmb_recipients.setItems(recipients);
    }

    private void populateReceptionistRecipients() {
        ObservableList<String> recipients = FXCollections.observableArrayList();
        recipients.add("Broadcast to All Guests");
        for (Guest guest : HotelDatabase.getGuests()) {
            recipients.add(guest.getUsername());
        }
        cmb_recipients.setItems(recipients);
    }


    private void connectToServer() {
        if (chatClient != null && chatClient.isConnected()) {
            showInfo("Already Connected", "Already connected to the chat server!");
            return;
        }

        btn_connect.setDisable(true);
        btn_connect.setText("🔄 Connecting...");

        // Connect in background thread
        Thread connectThread = new Thread(() -> {
            try {
                chatClient = new ChatClient("localhost", 5555);
                chatClient.setMessageListener(this::onMessageReceived);
                chatClient.login(currentUsername, currentRole);

                Platform.runLater(() -> {
                    lbl_status.setText("🟢 Connected");
                    lbl_status.setStyle("-fx-text-fill: #27ae60;");
                    btn_connect.setText("✅ Connected");
                    btn_connect.setStyle("-fx-background-color: #27ae60;");
                    txt_messages.appendText("[" + getCurrentTime() + "] Connected to chat server!\n");
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    lbl_status.setText("🔴 Failed");
                    btn_connect.setDisable(false);
                    btn_connect.setText("🔗 Connect");
                    showError("Connection Failed", "Could not connect to server: " + e.getMessage());
                });
            }
        });
        connectThread.setDaemon(true);
        connectThread.start();
    }

    private void sendMessage() {
        String message = txt_input.getText().trim();
        if (message.isEmpty()) {
            return;
        }

        if (chatClient == null || !chatClient.isConnected()) {
            showError("Not Connected", "Please connect to the server first!");
            return;
        }

        if (selectedRecipient == null || selectedRecipient.isEmpty()) {
            showError("No Recipient", "Please select a recipient!");
            return;
        }

        try {
            // Add to local display
            String displayName = currentUsername + " (You)";
            String displayMessage = "[" + getCurrentTime() + "] " + displayName + ": " + message + "\n";
            txt_messages.appendText(displayMessage);

            // Send to server
            if (selectedRecipient.equals("Broadcast to All Guests")) {
                chatClient.sendBroadcast(message);
            } else {
                chatClient.sendMessageTo(selectedRecipient, message);
            }

            txt_input.clear();
        } catch (Exception e) {
            showError("Send Error", "Failed to send message: " + e.getMessage());
        }
    }

    private void onMessageReceived(String sender, String message) {
        Platform.runLater(() -> {
            String displayMessage = "[" + getCurrentTime() + "] " + sender + ": " + message + "\n";
            txt_messages.appendText(displayMessage);
        });
    }

    private String getCurrentTime() {
        return LocalDateTime.now().format(timeFormatter);
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void showInfo(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    @FXML
    public void close() {
        if (chatClient != null) {
            chatClient.disconnect();
        }
    }
}
