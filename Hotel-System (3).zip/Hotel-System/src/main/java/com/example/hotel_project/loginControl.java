package com.example.hotel_project;

import BackEnd.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class loginControl {

    @FXML
    private Label errorLabel1;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private ToggleGroup roleGroup;

    @FXML
    private Button registerBtn;

    @FXML
    public void initialize() {
        errorLabel1.setVisible(false);
    }

    public void login(ActionEvent e) {

        String name = username.getText().trim();
        String pass = password.getText().trim();

        errorLabel1.setVisible(false);

        if (roleGroup.getSelectedToggle() == null) {
            errorLabel1.setVisible(true);
            errorLabel1.setText("Please select a role!");
            return;
        }

        if (name.isEmpty() || pass.isEmpty()) {
            errorLabel1.setVisible(true);
            errorLabel1.setText("Username and Password cannot be empty.");
            return;
        }

        ToggleButton selected = (ToggleButton) roleGroup.getSelectedToggle();
        String role = selected.getText();

        // ADMIN
        if (role.equals("Admin")) {
            if (Admin.login(name, pass)) {
                toAdminDashboard();
            } else {
                errorLabel1.setVisible(true);
                errorLabel1.setText("Wrong username or password!");
            }
        }

        // RECEPTIONIST
        else if (role.equals("Receptionist")) {
            if (Receptionist.login(name, pass)) {
                toReceptionistDashboard();
            } else {
                errorLabel1.setVisible(true);
                errorLabel1.setText("Wrong username or password!");
            }
        }

        // GUEST (بدون login حقيقي)
        else if (role.equals("Guest")) {
            if (Guest.login(name, pass)) {
                toGuestDashboard();
            } else {
                errorLabel1.setVisible(true);
                errorLabel1.setText("Wrong username or password!");        }
    }}

    // ADMIN DASHBOARD
    private void toAdminDashboard() {
        loadScene("/com/example/hotel_project/adminDashboard.fxml");
    }

    // RECEPTIONIST DASHBOARD
    private void toReceptionistDashboard() {
        loadScene("/com/example/hotel_project/ManageReceptionistWindow.fxml");
    }

    // GUEST DASHBOARD
    private void toGuestDashboard() {
        loadScene("/com/example/hotel_project/GuestDashboard.fxml");
    }

    // REGISTER PAGE
    @FXML
    public void toRegister(ActionEvent e) {
        loadScene("/com/example/hotel_project/Register.fxml");
    }

    // helper method
    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            Stage stage = (Stage) username.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException ex) {
            ex.getMessage();
        }
    }

    // EXIT
    public void exit() {
        System.exit(0);
    }
}

