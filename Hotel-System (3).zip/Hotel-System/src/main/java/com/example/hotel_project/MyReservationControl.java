package com.example.hotel_project;

import BackEnd.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.ArrayList;

public class MyReservationControl {

    // ─── FXML Table ────────────────────────────────────────────────────────────
    @FXML private TableView<Reservation>               tbl_reservations;
    @FXML private TableColumn<Reservation, String>     col_id;
    @FXML private TableColumn<Reservation, String>     col_room;
    @FXML private TableColumn<Reservation, String>     col_checkin;
    @FXML private TableColumn<Reservation, String>     col_checkout;
    @FXML private TableColumn<Reservation, String>     col_nights;
    @FXML private TableColumn<Reservation, String>     col_total;
    @FXML private TableColumn<Reservation, String>     col_status;

    @FXML private Button btn_cancel;
    @FXML private Button btn_checkout;
    @FXML private Button btn_back;
    @FXML private Label  lbl_balance;

    // ─── Initialize ────────────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        // bind columns
        col_id      .setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getId())));
        col_room    .setCellValueFactory(c -> new SimpleStringProperty("Room " + c.getValue().getRoom().getRoomNumber()));
        col_checkin .setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCheckInDate().toString()));
        col_checkout.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCheckOutDate().toString()));
        col_nights  .setCellValueFactory(c -> {
            long n = java.time.temporal.ChronoUnit.DAYS.between(
                    c.getValue().getCheckInDate(), c.getValue().getCheckOutDate());
            return new SimpleStringProperty(n + " night(s)");
        });
        col_total   .setCellValueFactory(c -> new SimpleStringProperty(
                String.format("%.0f EGP", c.getValue().getTotalPrice())));
        col_status  .setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatus().toString()));

        // color rows by status
        tbl_reservations.setRowFactory(tv -> new TableRow<Reservation>() {
            @Override
            protected void updateItem(Reservation r, boolean empty) {
                super.updateItem(r, empty);
                if (r == null || empty) {
                    setStyle("");
                } else {
                    switch (r.getStatus()) {
                        case CANCELLED:  setStyle("-fx-background-color: #ffe0e0;"); break;
                        case COMPLETED:  setStyle("-fx-background-color: #e0ffe0;"); break;
                        case CONFIRMED:  setStyle("-fx-background-color: #e0f0ff;"); break;
                        default:         setStyle("");
                    }
                }
            }
        });

        loadReservations();

        btn_cancel  .setOnAction(e -> handleCancel());
        btn_checkout.setOnAction(e -> handleCheckout());
        btn_back    .setOnAction(e -> goToDashboard());
    }

    // ─── Load data ─────────────────────────────────────────────────────────────
    private void loadReservations() {
        Guest guest = HotelDatabase.getCurrentGuest();
        if (guest == null) return;

        lbl_balance.setText(String.format("Balance: %.0f EGP", guest.getBalance()));

        ArrayList<Reservation> list = guest.viewMyReservations();
        ObservableList<Reservation> data = FXCollections.observableArrayList(list);
        tbl_reservations.setItems(data);
    }

    // ─── Cancel ────────────────────────────────────────────────────────────────
    private void handleCancel() {
        Reservation selected = tbl_reservations.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a reservation to cancel.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Cancel Reservation");
        confirm.setHeaderText(null);
        confirm.setContentText("Are you sure you want to cancel Reservation #" + selected.getId() + "?");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    HotelDatabase.getCurrentGuest().cancelReservation(selected);
                    showAlert(Alert.AlertType.INFORMATION, "Cancelled",
                            "Reservation #" + selected.getId() + " has been cancelled.");
                    loadReservations();
                } catch (IllegalStateException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                }
            }
        });
    }

    // ─── Checkout ──────────────────────────────────────────────────────────────
    private void handleCheckout() {
        Reservation selected = tbl_reservations.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a reservation to checkout.");
            return;
        }

        try {
            Invoice invoice = HotelDatabase.getCurrentGuest().checkout(selected);
            showAlert(Alert.AlertType.INFORMATION, "Checkout Successful ✅",
                    String.format("Invoice #%d%nTotal Paid: %.0f EGP%nPayment: %s%nDate: %s",
                            invoice.getId(),
                            invoice.getTotalAmount(),
                            invoice.getPaymentMethod(),
                            invoice.getPaymentDate()));
            loadReservations();
        } catch (InvalidPaymentException ex) {
            showAlert(Alert.AlertType.ERROR, "Payment Failed", ex.getMessage());
        } catch (IllegalStateException ex) {
            showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
        }
    }

    // ─── Navigation ────────────────────────────────────────────────────────────
    private void goToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/hotel_project/GuestDashBoard.fxml"));
            Stage stage = (Stage) btn_back.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
