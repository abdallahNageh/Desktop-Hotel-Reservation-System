package com.example.hotel_project;

import BackEnd.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.beans.property.SimpleStringProperty;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ManageRoomsController {

    @FXML private TextField roomNumberField;
    @FXML private TextField priceField;
    @FXML private TextField descriptionField;
    @FXML private ComboBox<String> typeComboBox;
    @FXML private MenuButton amenitiesMenuButton;
    @FXML private Label errorLabel; // لابل رسائل الخطأ في الواجهة

    @FXML private TableView<Room> roomsTable;
    @FXML private TableColumn<Room, Integer> colNumber;
    @FXML private TableColumn<Room, String> colType;
    @FXML private TableColumn<Room, Double> colPrice;
    @FXML private TableColumn<Room, String> colStatus;
    @FXML private TableColumn<Room, String> colAmenities;

    @FXML
    public void initialize() {
        typeComboBox.setItems(FXCollections.observableArrayList("Single", "Double", "Suite"));
        loadAmenitiesIntoMenu();
        amenitiesMenuButton.setOnShowing(e -> loadAmenitiesIntoMenu());

        // Table Columns
        colNumber.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("pricePerNight"));

        colStatus.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().isAvailable() ? "Available" : "Occupied")
        );

        colType.setCellValueFactory(cellData -> {
            Room room = cellData.getValue();
            if (room.getRoomType() != null && room.getRoomType().getName() != null) {
                return new SimpleStringProperty(room.getRoomType().getName().toString());
            }
            return new SimpleStringProperty("");
        });

        colAmenities.setCellValueFactory(cellData -> {
            List<Amenity> list = cellData.getValue().getAmenities();
            if (list == null || list.isEmpty()) return new SimpleStringProperty("None");
            String names = list.stream().map(Amenity::getName).collect(Collectors.joining(", "));
            return new SimpleStringProperty(names);
        });

        roomsTable.setItems(FXCollections.observableArrayList(HotelDatabase.getRooms()));
    }

    @FXML
    private void handleAddRoom() {
        resetError();
        String roomNumStr = roomNumberField.getText().trim();
        String priceStr = priceField.getText().trim();
        String descStr = descriptionField.getText().trim();
        String typeStr = typeComboBox.getValue();

        // التحقق من نسيان الحقول
        if (roomNumStr.isEmpty()) { showWarning("Room Number is required!"); return; }
        if (typeStr == null) { showWarning("Please select a Room Type!"); return; }
        if (priceStr.isEmpty()) { showWarning("Price is required!"); return; }
        if (descStr.isEmpty()) { showWarning("Description is required!"); return; }

        try {
            int number = Integer.parseInt(roomNumStr);
            if (number <= 0) { showWarning("Room Number must be positive!"); return; }
            if (HotelDatabase.findRoom(number) != null) { showWarning("Room number already exists!"); return; }

            double price = Double.parseDouble(priceStr);
            if (price <= 0) { showWarning("Price must be positive!"); return; }

            RoomTypeName typeName = RoomTypeName.valueOf(typeStr.toUpperCase());
            RoomType rt = new RoomType(typeName, descStr, price);
            List<Amenity> ams = getSelectedAmenities();

            Room newRoom = new Room(number, ams, true, rt);
            newRoom.setPricePerNight(price);

            HotelDatabase.getRooms().add(newRoom);
            roomsTable.getItems().add(newRoom);

            clearFields();
            showInfo("Success", "Room added successfully!");

        } catch (NumberFormatException e) {
            showWarning("Number or Price must be valid numbers!");
        } catch (Exception e) {
            showWarning("Error occurred: " + e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        resetError();
        Room selectedRoom = roomsTable.getSelectionModel().getSelectedItem();
        if (selectedRoom == null) { showWarning("Select a room from the table to edit!"); return; }

        String roomNumStr = roomNumberField.getText().trim();
        String priceStr = priceField.getText().trim();
        String descStr = descriptionField.getText().trim();
        String typeStr = typeComboBox.getValue();

        // يجب إدخال شيء واحد على الأقل لتعديله
        if (roomNumStr.isEmpty() && priceStr.isEmpty() && descStr.isEmpty() && typeStr == null && getSelectedAmenities().isEmpty()) {
            showWarning("Enter new data in fields to update the selected room!");
            return;
        }

        try {
            if (!roomNumStr.isEmpty()) {
                int newNumber = Integer.parseInt(roomNumStr);
                if (newNumber <= 0) throw new NumberFormatException();
                if (newNumber != selectedRoom.getRoomNumber() && HotelDatabase.findRoom(newNumber) != null) {
                    showWarning("The new room number already exists!");
                    return;
                }
                selectedRoom.setRoomNumber(newNumber);
            }

            if (selectedRoom.getRoomType() != null) {
                if (typeStr != null) selectedRoom.getRoomType().setName(RoomTypeName.valueOf(typeStr.toUpperCase()));
                if (!descStr.isEmpty()) selectedRoom.getRoomType().setDescription(descStr);
                if (!priceStr.isEmpty()) {
                    double newPrice = Double.parseDouble(priceStr);
                    if (newPrice <= 0) throw new NumberFormatException();
                    selectedRoom.setPricePerNight(newPrice);
                    selectedRoom.getRoomType().setBasePrice(newPrice);
                }
            }

            List<Amenity> selectedAms = getSelectedAmenities();
            if (!selectedAms.isEmpty()) selectedRoom.setAmenities(new ArrayList<>(selectedAms));

            roomsTable.refresh();
            clearFields();
            showInfo("Updated", "Room data updated successfully!");

        } catch (NumberFormatException e) {
            showWarning("Invalid numeric values for number or price!");
        }
    }

    @FXML
    private void handleDeleteRoom() {
        resetError();
        Room selected = roomsTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            HotelDatabase.getRooms().remove(selected);
            roomsTable.getItems().remove(selected);
            showInfo("Deleted", "Room deleted successfully.");
        } else {
            showWarning("Please select a room from the table first!");
        }
    }

    @FXML
    private void handleBack() {
        // يتم كتابة كود الانتقال هنا
    }

    // --- الدوال المساعدة للتنبيهات ---

    private void showWarning(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void resetError() {
        errorLabel.setVisible(false);
    }

    private void showInfo(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // --- دوال الـ Amenities و Clear ---

    private void loadAmenitiesIntoMenu() {
        List<String> selectedNames = getSelectedAmenityNames();
        amenitiesMenuButton.getItems().clear();
        for (Amenity amenity : HotelDatabase.getAmenities()) {
            if (amenity == null) continue;
            CheckMenuItem item = new CheckMenuItem(amenity.getName());
            item.setUserData(amenity);
            if (selectedNames.contains(amenity.getName())) item.setSelected(true);
            item.setOnAction(e -> updateMenuText());
            amenitiesMenuButton.getItems().add(item);
        }
        updateMenuText();
    }

    private List<String> getSelectedAmenityNames() {
        List<String> names = new ArrayList<>();
        for (MenuItem item : amenitiesMenuButton.getItems()) {
            if (item instanceof CheckMenuItem && ((CheckMenuItem) item).isSelected()) names.add(item.getText());
        }
        return names;
    }

    private void updateMenuText() {
        List<String> selected = getSelectedAmenityNames();
        amenitiesMenuButton.setText(selected.isEmpty() ? "Select Amenities" : String.join(", ", selected));
    }

    private List<Amenity> getSelectedAmenities() {
        List<Amenity> selected = new ArrayList<>();
        for (MenuItem item : amenitiesMenuButton.getItems()) {
            if (item instanceof CheckMenuItem && ((CheckMenuItem) item).isSelected()) {
                selected.add((Amenity) item.getUserData());
            }
        }
        return selected;
    }

    private void clearFields() {
        roomNumberField.clear();
        priceField.clear();
        descriptionField.clear();
        typeComboBox.getSelectionModel().clearSelection();
        for (MenuItem item : amenitiesMenuButton.getItems()) {
            if (item instanceof CheckMenuItem) ((CheckMenuItem) item).setSelected(false);
        }
        amenitiesMenuButton.setText("Select Amenities");
        resetError();
    }
    @FXML
    private void handleBack(ActionEvent event) throws Exception {
        try {
            // تحميل ملف الـ FXML الخاص بالداشبورد
            FXMLLoader loader = new FXMLLoader(getClass().getResource("adminDashboard.fxml"));
            Parent root = loader.load();

            // الحصول على النافذة (Stage) الحالية من الحدث (event)
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // ضبط المشهد الجديد بالأبعاد المطلوبة
            Scene scene = new Scene(root, 1200, 900);

            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            showWarning("Could not load Admin Dashboard: " + e.getMessage());
        }
    }
}

