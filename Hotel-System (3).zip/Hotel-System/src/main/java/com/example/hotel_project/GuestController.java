package com.example.hotel_project;

import javafx.scene.input.MouseEvent;
import BackEnd.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GuestController {

    @FXML private Label  hi_userName;
    @FXML private Button ViewAvilableRooms;
    @FXML private Button ViewMyReservation;
    @FXML private Button btn_chat;
    @FXML private Button btn_logout;

    @FXML
    public void initialize() {
        Guest currentGuest = HotelDatabase.getCurrentGuest();
        if (currentGuest != null) {
            hi_userName.setText("Hi, " + currentGuest.getUsername() + " 👋  |  Balance: "
                    + String.format("%.0f", currentGuest.getBalance()) + " EGP");
        }

        ViewAvilableRooms.setOnAction(e -> loadScene("/com/example/hotel_project/ViewAvailableRoom.fxml"));
        ViewMyReservation.setOnAction(e -> loadScene("/com/example/hotel_project/MyReservations.fxml"));

        if (btn_chat != null) {
            btn_chat.setOnAction(e -> openChatWindow());
        }

        if (btn_logout != null) {
            btn_logout.setOnAction(e -> {
                HotelDatabase.setCurrentGuest(null);
                loadScene("/com/example/hotel_project/login.fxml");
            });
        }
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Stage stage = (Stage) hi_userName.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openChatWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/ChatWindow.fxml"));
            Stage chatStage = new Stage();
            chatStage.setTitle("💬 Live Chat with Receptionist");
            chatStage.setScene(new Scene(loader.load(), 600, 700));
            chatStage.show();
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Could not open chat window: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void onHoverRooms(MouseEvent mouseEvent) {
    }

    public void onLeaveRooms(MouseEvent mouseEvent) {
    }
}
