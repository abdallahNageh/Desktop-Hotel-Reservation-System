package com.example.hotel_project;

import BackEnd.HotelDatabase;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class ReceptionistController {

    @FXML
    private StackPane contentArea;

    private void loadScreen(String fxmlFile) {
        try {
            Pane pane = FXMLLoader.load(getClass().getResource(fxmlFile));
            contentArea.getChildren().setAll(pane);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showDashboard() {
        loadScreen("ManageReceptionistDashboard.fxml");
    }

    @FXML
    private void showGuests() {
        loadScreen("ManageReceptionistGuests.fxml");
    }

    @FXML
    private void showRooms() {
        loadScreen("ManageReceptionistRooms.fxml");
    }

    @FXML
    private void showReservations() {
        loadScreen("ManageReceptionistReservations.fxml");
    }

    @FXML
    private void showCheckIn() {
        loadScreen("ManageReceptionistCheckIn.fxml");
    }

    @FXML
    private void showChat() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/hotel_project/ChatWindow.fxml"));
            Stage chatStage = new Stage();
            chatStage.setScene(new Scene(loader.load()));
            chatStage.setTitle("💬 Live Chat - Receptionist");
            chatStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void logout() {
        try{
            Parent back = FXMLLoader.load(getClass().getResource("login.fxml"));
            Scene scene = new Scene(back);
            Stage stage = (Stage) contentArea.getScene().getWindow();
            stage.setScene(scene);
            HotelDatabase.setCurrentReceptionist(null);
        }
        catch (Exception e){
            e.getMessage();
        }
    }
}