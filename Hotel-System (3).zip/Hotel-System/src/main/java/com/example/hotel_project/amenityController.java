package com.example.hotel_project;

import BackEnd.Amenity;
import BackEnd.HotelDatabase;
import BackEnd.Room;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;


public class amenityController {
    @FXML private TableView<Amenity> amenitiesTable;
    @FXML private TableColumn<Amenity, Integer> idCol;
    @FXML
    private TableColumn<Amenity, String> nameCol;
    @FXML private TableColumn<Amenity, String> descriptionCol;
    @FXML private TextField nameField;
    @FXML private TextField descriptionField;
    @FXML private Label erroLabel ;
    private ObservableList<Amenity> amenityList;
    @FXML
    public void initialize(){
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        amenityList = FXCollections.observableArrayList(HotelDatabase.getAmenities());
        amenitiesTable.setItems(amenityList);
    }
    @FXML
    private void handleAdd() {
        String name = nameField.getText().trim();
        String desc = descriptionField.getText().trim();
        erroLabel.setVisible(false);

        if (name.isEmpty()) {
            erroLabel.setVisible(true);
            erroLabel.setText("You must Enter the name !!");
            return;}
        Amenity newAmenity = new Amenity(name, desc);
        HotelDatabase.addAmenity(newAmenity);  // أضفها للـ database
        amenityList.add(newAmenity);           // أضفها للـ table
        clearFields();
    }
    private void clearFields() {
        nameField.clear();
        descriptionField.clear();
    }
    @FXML
    private void handleEdit() {
        Amenity selected = amenitiesTable.getSelectionModel().getSelectedItem();
        String newName= nameField.getText().trim();
        String newDescription=descriptionField.getText().trim();
        erroLabel.setVisible(false);
        if (selected == null) {
            erroLabel.setVisible(true);
            erroLabel.setText("you must select the amenity first!!!");
            return;}

        if(newName.isEmpty() && newDescription.isEmpty())  {
            erroLabel.setVisible(true);
            erroLabel.setText("You should enter the new name or the new description!!!");
            return;}
        else if (newDescription.isEmpty())
            selected.setName(nameField.getText().trim());
        else if (newName.isEmpty())
            selected.setDescription(descriptionField.getText().trim());
        else {
            selected.setName(nameField.getText().trim());
            selected.setDescription(descriptionField.getText().trim());
        }


        // تحديث الـ table
        amenitiesTable.refresh();
    }
    @FXML
    private void handleDelete() {
        Amenity selected = amenitiesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            erroLabel.setVisible(true);
            erroLabel.setText("you must select the amenity first!!!");
            return;
        }
        for(Room r :HotelDatabase.getRooms() ){
            r.getAmenities().remove(selected);
        }
        HotelDatabase.removeAmenity(selected);  // احذفها من الـ database
        amenityList.remove(selected);           // احذفها من الـ table
    }

    @FXML
    private void handleBackToMenu(ActionEvent event) {
        try {
            // تحميل ملف الـ FXML الخاص بالداشبورد
            FXMLLoader loader = new FXMLLoader(getClass().getResource("adminDashboard.fxml"));
            Parent root = loader.load();

            // الحصول على النافذة (Stage) الحالية
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // تعيين المشهد الجديد بالأبعاد الموحدة
            Scene scene = new Scene(root, 1200, 900);

            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            // في حال فشل التحميل، يمكنك طباعة الخطأ أو إظهار تنبيه
            System.err.println("Error: Could not load adminDashboard.fxml - " + e.getMessage());
        }
    }
}
