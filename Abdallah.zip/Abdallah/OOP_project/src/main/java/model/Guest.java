package model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Guest {

    // ─── Attributes ────────────────────────────────────────────────────────────
    private String username;
    private String password;          // validated: min 8 chars, has digit & uppercase
    private LocalDate dateOfBirth;    // LocalDate (not legacy Date)
    private double balance;
    private String address;
    private Gender gender;            // enum: MALE / FEMALE
    private String roomPreferences;   // e.g. "SUITE, floor 3"

    public static int noOfguest = 0;

    // ─── equals ────────────────────────────────────────────────────────────────
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Guest)) return false;
        Guest guest = (Guest) o;
        return this.username.equals(guest.username) && this.password.equals(guest.password);
    }

    // ─── Password Validation ───────────────────────────────────────────────────
    /**
     * Password rules:
     *  - At least 8 characters
     *  - Contains at least one digit
     *  - Contains at least one uppercase letter
     */
    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasDigit = false;
        boolean hasUpper = false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c))     hasDigit = true;
            if (Character.isUpperCase(c)) hasUpper = true;
        }
        return hasDigit && hasUpper;
    }

    // ─── Constructor ───────────────────────────────────────────────────────────
    public Guest(String username, String password) {
        this.username = username;
        this.password = password;
        noOfguest++;
    }

    // ─── Behaviors ─────────────────────────────────────────────────────────────

    /**
     * Register a new Guest and add it to HotelDatabase.
     * Returns false if username taken or password invalid.
     */
    public boolean register(String username, String password, Gender gender,
                            LocalDate dateOfBirth, String address,
                            double balance, String roomPreferences) {

        if (!isValidPassword(password)) {
            System.out.println("Registration failed: Password must be at least 8 characters, " +
                               "contain a digit and an uppercase letter.");
            return false;
        }
        if (HotelDatabase.findGuest(username) != null) {
            System.out.println("Registration failed: Username already exists.");
            return false;
        }

        Guest newGuest = new Guest(username, password);
        newGuest.setDateOfBirth(dateOfBirth);
        newGuest.setGender(gender);
        newGuest.setAddress(address);
        newGuest.setBalance(balance);
        newGuest.setRoomPreferences(roomPreferences);
        HotelDatabase.addGuest(newGuest);
        return true;
    }

    /**
     * Login: finds the guest in DB, sets currentGuest, returns true on success.
     */
    public boolean login(String username, String password) {
        for (Guest g : HotelDatabase.getGuests()) {
            if (g.getUsername().equals(username) && g.getPassword().equals(password)) {
                HotelDatabase.setCurrentGuest(g);
                return true;
            }
        }
        return false;
    }

    /**
     * Returns all rooms currently marked as available.
     */
    public ArrayList<Room> viewAvailableRooms() {
        ArrayList<Room> available = new ArrayList<>();
        for (Room r : HotelDatabase.getRooms()) {
            if (r.isAvailable()) {
                available.add(r);
            }
        }
        return available;
    }

    /**
     * Creates a Reservation, marks room unavailable, saves to DB.
     * Throws RoomNotAvailableException if room is taken.
     */
    public Reservation makeReservation(Room room, LocalDate checkIn, LocalDate checkOut)
            throws RoomNotAvailableException {

        if (!room.isAvailable()) {
            throw new RoomNotAvailableException(
                "Booking failed: Room " + room.getRoomNumber() + " is currently unavailable.");
        }
        room.setAvailable(false);
        Reservation reservation = new Reservation(this, room, checkIn, checkOut);
        HotelDatabase.addReservation(reservation);
        return reservation;
    }

    /**
     * Returns all reservations that belong to this guest.
     */
    public ArrayList<Reservation> viewMyReservations() {
        ArrayList<Reservation> myReservations = new ArrayList<>();
        for (Reservation r : HotelDatabase.getReservations()) {
            if (r.getGuest().equals(this)) {
                myReservations.add(r);
            }
        }
        return myReservations;
    }

    /**
     * Cancels a reservation: sets status CANCELLED and frees the room.
     */
    public void cancelReservation(Reservation reservation) {
        if (reservation.getStatus() == ReservationStatus.COMPLETED ||
            reservation.getStatus() == ReservationStatus.CANCELLED) {
            throw new IllegalStateException("Cannot cancel a completed or already cancelled reservation.");
        }
        reservation.setStatus(ReservationStatus.CANCELLED);
        reservation.getRoom().setAvailable(true);
    }

    /**
     * Checkout: calculates total, creates Invoice, deducts balance,
     * marks room available, sets reservation COMPLETED.
     */
    public Invoice checkout(Reservation reservation) throws InvalidPaymentException {
        if (reservation.getStatus() == ReservationStatus.CANCELLED) {
            throw new IllegalStateException("Cannot checkout a cancelled reservation.");
        }
        if (reservation.getStatus() == ReservationStatus.COMPLETED) {
            throw new IllegalStateException("This reservation was already checked out.");
        }

        long nights = java.time.temporal.ChronoUnit.DAYS.between(
                reservation.getCheckInDate(), reservation.getCheckOutDate());
        double total = nights * reservation.getRoom().getPricePerNight();

        Invoice invoice = new Invoice(total, PaymentMethod.CASH, LocalDate.now());
        invoice.pay(this);   // throws InvalidPaymentException if balance < total

        HotelDatabase.addInvoice(invoice);
        reservation.getRoom().setAvailable(true);
        reservation.setStatus(ReservationStatus.COMPLETED);
        return invoice;
    }

    // ─── Getters & Setters ─────────────────────────────────────────────────────

    public String getUsername()                   { return username; }
    public void   setUsername(String username)    { this.username = username; }

    public String getPassword()                   { return password; }
    public void   setPassword(String password)    { this.password = password; }

    public LocalDate getDateOfBirth()             { return dateOfBirth; }
    public void      setDateOfBirth(LocalDate d)  { this.dateOfBirth = d; }

    public double getBalance()                    { return balance; }
    public void   setBalance(double balance)      { this.balance = balance; }

    public String getAddress()                    { return address; }
    public void   setAddress(String address)      { this.address = address; }

    public Gender getGender()                     { return gender; }
    public void   setGender(Gender gender)        { this.gender = gender; }

    public String getRoomPreferences()            { return roomPreferences; }
    public void   setRoomPreferences(String rp)   { this.roomPreferences = rp; }

    @Override
    public String toString() {
        return "Guest{username='" + username + "', gender=" + gender +
               ", balance=" + balance + "}";
    }
}
