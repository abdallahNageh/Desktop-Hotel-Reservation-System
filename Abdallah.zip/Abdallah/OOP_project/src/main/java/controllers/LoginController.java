package controllers;

import model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField     Usernme;
    @FXML private PasswordField Password;
    @FXML private Label         lbl_error;

    @FXML
    public void initialize() {
        if (lbl_error != null) lbl_error.setText("");
    }

    @FXML
    private void handleLogin() {
        String user = Usernme.getText().trim();
        String pass = Password.getText();

        if (user.isEmpty() || pass.isEmpty()) {
            if (lbl_error != null) lbl_error.setText("Please enter username and password.");
            return;
        }

        Guest guest = new Guest("", "");
        Guest.noOfguest--;          // undo count from temp object
        if (guest.login(user, pass)) {
            loadScene("/com/example/oop_project/DashBoard.fxml");
        } else {
            if (lbl_error != null) lbl_error.setText("Invalid username or password.");
            else System.out.println("Login Failed");
        }
    }

    @FXML
    private void handleRegister() {
        loadScene("/com/example/oop_project/Register.fxml");
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Stage stage = (Stage) Usernme.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
