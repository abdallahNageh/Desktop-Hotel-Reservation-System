package controllers;

import model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.time.LocalDate;

public class RegisterController {

    // ─── FXML Fields ───────────────────────────────────────────────────────────
    @FXML private TextField     tf_username;
    @FXML private PasswordField pf_password;
    @FXML private PasswordField pf_confirm;
    @FXML private DatePicker    dp_dob;
    @FXML private ComboBox<String> cb_gender;
    @FXML private TextField     tf_address;
    @FXML private TextField     tf_balance;
    @FXML private TextField     tf_preferences;
    @FXML private Label         lbl_error;

    // ─── Initialize ────────────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        cb_gender.getItems().addAll("MALE", "FEMALE");
        cb_gender.setValue("MALE");
        lbl_error.setText("");
    }

    // ─── Handle Register Button ─────────────────────────────────────────────────
    @FXML
    private void handleRegister() {
        lbl_error.setText("");

        String username    = tf_username.getText().trim();
        String password    = pf_password.getText();
        String confirm     = pf_confirm.getText();
        LocalDate dob      = dp_dob.getValue();
        String genderStr   = cb_gender.getValue();
        String address     = tf_address.getText().trim();
        String balanceStr  = tf_balance.getText().trim();
        String preferences = tf_preferences.getText().trim();

        // ── Validation ──────────────────────────────────────────────────────────
        if (username.isEmpty() || password.isEmpty() || address.isEmpty()) {
            lbl_error.setText("Please fill in all required fields.");
            return;
        }
        if (!password.equals(confirm)) {
            lbl_error.setText("Passwords do not match.");
            return;
        }
        if (!Guest.isValidPassword(password)) {
            lbl_error.setText("Password must be ≥8 chars, include a digit and an uppercase letter.");
            return;
        }
        if (dob == null) {
            lbl_error.setText("Please select your date of birth.");
            return;
        }
        if (dob.isAfter(LocalDate.now().minusYears(10))) {
            lbl_error.setText("You must be at least 10 years old to register.");
            return;
        }

        double balance = 0;
        try {
            balance = Double.parseDouble(balanceStr);
            if (balance < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            lbl_error.setText("Balance must be a non-negative number.");
            return;
        }

        Gender gender = genderStr.equals("FEMALE") ? Gender.FEMALE : Gender.MALE;

        // ── Register ────────────────────────────────────────────────────────────
        Guest temp = new Guest("", "");
        Guest.noOfguest--; // undo the count from the temp object
        boolean success = temp.register(username, password, gender, dob, address, balance, preferences);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Success",
                    "Account created successfully! Please login.");
            goToLogin();
        } else {
            lbl_error.setText("Username already exists. Please choose another.");
        }
    }

    // ─── Handle Back to Login ───────────────────────────────────────────────────
    @FXML
    private void handleBackToLogin() {
        goToLogin();
    }

    private void goToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/oop_project/hello-view.fxml"));
            Stage stage = (Stage) tf_username.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
