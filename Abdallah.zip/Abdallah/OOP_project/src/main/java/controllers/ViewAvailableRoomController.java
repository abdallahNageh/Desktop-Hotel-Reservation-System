package controllers;

import javafx.scene.control.*;
import model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.util.ArrayList;

public class ViewAvailableRoomController {

    // ─── FXML Elements ──────────────────────────────────────────────────────────
    @FXML private TreeView<String> list;
    @FXML private Button           reservation_btn;
    @FXML private Button           btn_back;
    @FXML private DatePicker       Checkin_date;
    @FXML private DatePicker       Checkout_Data;

    // ─── Initialize ─────────────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        Checkin_date.setValue(LocalDate.now());
        Checkout_Data.setValue(LocalDate.now().plusDays(1));

        loadAvailableRooms();

        Checkin_date.setOnAction(e -> loadAvailableRooms());
        Checkout_Data.setOnAction(e -> loadAvailableRooms());
        reservation_btn.setOnAction(e -> handleMakeReservation());
        if (btn_back != null) btn_back.setOnAction(e -> handleBack());
    }

    // ─── Load available rooms ────────────────────────────────────────────────────
    private void loadAvailableRooms() {
        TreeItem<String> root = new TreeItem<>("Rooms");
        root.setExpanded(true);

        Guest guest = HotelDatabase.getCurrentGuest();
        if (guest == null) return;

        ArrayList<Room> availableRooms = guest.viewAvailableRooms();

        if (availableRooms.isEmpty()) {
            root.getChildren().add(new TreeItem<>("No available rooms found."));
        } else {
            for (Room room : availableRooms) {
                String roomLabel = String.format(
                        "Room %d  |  %s  |  %.0f EGP/night",
                        room.getRoomNumber(),
                        room.getRoomType().toString(),
                        room.getPricePerNight());
                TreeItem<String> roomItem = new TreeItem<>("🛏  " + roomLabel);

                roomItem.getChildren().add(new TreeItem<>("   📦 Type: " + room.getRoomType()));
                roomItem.getChildren().add(new TreeItem<>("   💰 Price/night: " + room.getPricePerNight() + " EGP"));
                roomItem.getChildren().add(new TreeItem<>("   ✅ Status: Available"));

                if (room.getAmenities() != null && !room.getAmenities().isEmpty()) {
                    TreeItem<String> amenitiesItem = new TreeItem<>("   🎁 Amenities:");
                    for (Amenity a : room.getAmenities()) {
                        amenitiesItem.getChildren().add(
                                new TreeItem<>("      • " + a.getName() + " — " + a.getDescription()));
                    }
                    roomItem.getChildren().add(amenitiesItem);
                }

                roomItem.setExpanded(true);
                root.getChildren().add(roomItem);
            }
        }

        list.setRoot(root);
        list.setShowRoot(false);
    }

    // ─── Make Reservation ────────────────────────────────────────────────────────
    private void handleMakeReservation() {
        LocalDate checkin  = Checkin_date.getValue();
        LocalDate checkout = Checkout_Data.getValue();

        if (checkin == null || checkout == null) {
            showAlert(Alert.AlertType.WARNING, "Missing Dates", "Please select check-in and check-out dates.");
            return;
        }
        if (!checkout.isAfter(checkin)) {
            showAlert(Alert.AlertType.ERROR, "Invalid Dates", "Check-out date must be after check-in date.");
            return;
        }

        TreeItem<String> selected = list.getSelectionModel().getSelectedItem();
        if (selected == null || !selected.getValue().contains("Room")) {
            showAlert(Alert.AlertType.WARNING, "No Room Selected", "Please select a room from the list first.");
            return;
        }

        String text = selected.getValue();
        int roomNumber = -1;
        try {
            String cleaned = text.replaceAll("[^\\d ]", " ").trim();
            String[] parts = cleaned.trim().split("\\s+");
            roomNumber = Integer.parseInt(parts[0]);
        } catch (Exception ex) {
            showAlert(Alert.AlertType.WARNING, "Selection Error", "Please click on the main room row (not a detail row).");
            return;
        }

        Room selectedRoom = HotelDatabase.findRoom(roomNumber);
        if (selectedRoom == null) {
            showAlert(Alert.AlertType.ERROR, "Room Not Found", "Could not find room #" + roomNumber);
            return;
        }

        Guest guest = HotelDatabase.getCurrentGuest();
        try {
            guest.makeReservation(selectedRoom, checkin, checkout);
            long nights = java.time.temporal.ChronoUnit.DAYS.between(checkin, checkout);
            double total = nights * selectedRoom.getPricePerNight();
            showAlert(Alert.AlertType.INFORMATION, "Booking Confirmed ✅",
                    "Room " + selectedRoom.getRoomNumber() + " booked!\n" +
                    "Check-in:  " + checkin + "\n" +
                    "Check-out: " + checkout + "\n" +
                    "Duration:  " + nights + " night(s)\n" +
                    "Total:     " + total + " EGP");
            loadAvailableRooms();
        } catch (RoomNotAvailableException ex) {
            showAlert(Alert.AlertType.ERROR, "Room Unavailable", ex.getMessage());
        }
    }

    // ─── Back to Dashboard ───────────────────────────────────────────────────────
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/oop_project/DashBoard.fxml"));
            Stage stage = (Stage) list.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ─── Alert helper ────────────────────────────────────────────────────────────
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
