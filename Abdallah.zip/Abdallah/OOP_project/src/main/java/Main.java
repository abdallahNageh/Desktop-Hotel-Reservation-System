import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        initSampleData();

        Parent root = FXMLLoader.load(
                getClass().getResource("/com/example/oop_project/hello-view.fxml"));
        stage.setTitle("Hotel Reservation System");
        stage.setScene(new Scene(root));
        stage.show();
    }

    /** Populates DB with sample rooms and one test guest for quick testing. */
    private void initSampleData() {
        HotelDatabase.initializeData();

        // ── Sample Amenities ────────────────────────────────────────────────
        Amenity wifi = new Amenity("WiFi",    "High-speed internet");
        Amenity tv   = new Amenity("Smart TV","55-inch smart TV");
        Amenity pool = new Amenity("Pool",    "Access to rooftop pool");
        Amenity gym  = new Amenity("Gym",     "24-hour gym access");
        HotelDatabase.addAmenity(wifi);
        HotelDatabase.addAmenity(tv);
        HotelDatabase.addAmenity(pool);
        HotelDatabase.addAmenity(gym);

        // ── Room Types ──────────────────────────────────────────────────────
        RoomType single = new RoomType(RoomTypeName.SINGLE, "Single room", 500);
        RoomType dbl    = new RoomType(RoomTypeName.DOUBLE, "Double room", 800);
        RoomType suite  = new RoomType(RoomTypeName.SUITE,  "Suite",      1500);
        HotelDatabase.addRoomType(single);
        HotelDatabase.addRoomType(dbl);
        HotelDatabase.addRoomType(suite);

        // ── Rooms ───────────────────────────────────────────────────────────
        Room r101 = new Room(101, new ArrayList<>(Arrays.asList(wifi, tv)),   true, single);
        Room r102 = new Room(102, new ArrayList<>(Arrays.asList(wifi, tv)),   true, single);
        Room r201 = new Room(201, new ArrayList<>(Arrays.asList(wifi, tv, pool)), true, dbl);
        Room r202 = new Room(202, new ArrayList<>(Arrays.asList(wifi, tv)),   true, dbl);
        Room r301 = new Room(301, new ArrayList<>(Arrays.asList(wifi, tv, pool, gym)), true, suite);
        r101.setPricePerNight(500);
        r102.setPricePerNight(500);
        r201.setPricePerNight(800);
        r202.setPricePerNight(800);
        r301.setPricePerNight(1500);
        HotelDatabase.addRoom(r101);
        HotelDatabase.addRoom(r102);
        HotelDatabase.addRoom(r201);
        HotelDatabase.addRoom(r202);
        HotelDatabase.addRoom(r301);

        // ── Test Guest (for quick demo: username=test, password=Test1234) ──
        Guest demo = new Guest("test", "Test1234");
        demo.setGender(Gender.MALE);
        demo.setDateOfBirth(LocalDate.of(2000, 1, 15));
        demo.setAddress("10 Tahrir St, Cairo");
        demo.setBalance(10000);
        demo.setRoomPreferences("SUITE, high floor");
        HotelDatabase.addGuest(demo);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
